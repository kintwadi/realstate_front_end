import { Component } from '@angular/core';

@Component({
    selector: 'app-help',
    imports: [],
    templateUrl: './help.component.html',
    styleUrls: ['./help.component.scss']
})
export class HelpComponent {

}
