export const invoiceData = [
  {
    description: "Residences can be classified in residence.",
    deposit: "$400",
    rate: "$580",
    total: "$800.00",
  },
  {
    description: "Residences can be classified in residence.",
    deposit: "$300",
    rate: "$450",
    total: "$900.00",
  },
]
