import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
    selector: 'app-agent-details',
    imports: [RouterModule],
    templateUrl: './agent-details.component.html',
    styleUrls: ['./agent-details.component.scss']
})

export class AgentDetailsComponent {

}
