import { Component } from '@angular/core';
import { invoiceData } from '../../../shared/data/data/agent/agent';
import { NgxPrintModule } from 'ngx-print';

@Component({
    selector: 'app-invoice',
    imports: [NgxPrintModule],
    templateUrl: './invoice.component.html',
    styleUrls: ['./invoice.component.scss']
})
export class InvoiceComponent {

  public invoiceData = invoiceData;

}
