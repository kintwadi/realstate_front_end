import { Component } from '@angular/core';

@Component({
    selector: 'app-chart-legends',
    imports: [],
    templateUrl: './chart-legends.component.html',
    styleUrls: ['./chart-legends.component.scss']
})
export class ChartLegendsComponent {

}
