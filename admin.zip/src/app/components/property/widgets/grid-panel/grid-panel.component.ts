import { Component } from '@angular/core';

@Component({
    selector: 'app-grid-panel',
    imports: [],
    templateUrl: './grid-panel.component.html',
    styleUrls: ['./grid-panel.component.scss']
})
export class GridPanelComponent {

}
