import { Component } from '@angular/core';

@Component({
    selector: 'app-monthly-installment',
    imports: [],
    templateUrl: './monthly-installment.component.html',
    styleUrls: ['./monthly-installment.component.scss']
})

export class MonthlyInstallmentComponent {

}
