import { Component } from '@angular/core';

@Component({
    selector: 'app-about-user',
    imports: [],
    templateUrl: './about-user.component.html',
    styleUrls: ['./about-user.component.scss']
})

export class AboutUserComponent {

}
